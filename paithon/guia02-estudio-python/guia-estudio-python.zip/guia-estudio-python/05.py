def ing_num (numero):
    numeros= []
    for i in range(n):
        num = int(input(f'ingrese el {i+1}° número: '))
        numeros.append(num)
    print(f'Números ingresados: {numeros}')
     

def inum (nume):
    
        while True:
            nume=(num)
            if nume == -1:
                break
        else:
          print(nume)

def calculo(num):
      suma= sum(num)
      print(suma)
      if num % 2 == 0:
          par= sum(num)
          print(par)

      else:
            impar= sum(num)
            print(impar)

n= int(input('Cuantos números desea ingresar:\n'))
ing_num(numero=)